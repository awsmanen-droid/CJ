# C&J ❤️ · Calendario de Adviento 2026

## Arrancar
```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # comprueba tipos y compila
```
Simular fechas (solo en `npm run dev`): `http://localhost:5173/calendario?fecha=2026-12-05`

## Despliegue
Pendiente de autorización. Vercel: importar el repo, framework Vite, y añadir una regla de reescritura a `index.html` para las rutas de React Router.

## Supabase (fase 3 y 6)
1. Crea un proyecto en supabase.com. En Authentication → Sign In / Providers, **desactiva "Allow new users to sign up"**.
2. SQL Editor: ejecuta en orden `supabase/migrations/0001_init.sql`, `supabase/seed.sql` y `supabase/create_first_invite.sql`. Este último devuelve el token: guárdalo.
3. Copia `.env.example` a `.env` y rellena `VITE_SUPABASE_URL` y `VITE_SUPABASE_ANON_KEY`.
4. Enlace de Claudia: `https://TU-DOMINIO/i/<token>`. Al abrirlo, el token se guarda en el navegador y se quita de la URL.
5. Para el admin: crea tu usuario en Authentication → Users y ejecuta
   `insert into public.admin_users (user_id) values ('<UUID de tu usuario>');`

### Cómo se protege
- Las tablas no son accesibles para visitantes. Todo pasa por `get_calendar`, `open_day` y `redeem_day`, que validan el token (guardado como hash) y la hora del **servidor** en Europe/Madrid.
- `get_calendar` nunca devuelve contenido. `open_day` solo devuelve días publicados y ya desbloqueados.
- Regenerar el enlace (`create_invite_token`) revoca el anterior y conserva el progreso.

## Archivos multimedia (Storage)
1. Ejecuta también `supabase/migrations/0002_storage.sql` (crea 5 buckets privados con límites de tamaño y formato).
2. Despliega la función que firma las URLs (necesitas la [Supabase CLI](https://supabase.com/docs/guides/cli)):
   `supabase login` → `supabase link --project-ref <ref>` → `supabase functions deploy sign-media`
3. Sin panel todavía, puedes cargar contenido a mano: sube el archivo en Storage (p. ej. bucket `photos`, objeto `day-2/foto1.jpg`) y enlázalo en el JSON del día:
```sql
update public.advent_days set content = '{"description":"Texto","photos":[{"path":"photos/day-2/foto1.jpg","caption":"Pie de foto"}]}' where day_number = 2;
-- vídeo: {"description":"..","video_path":"videos/day-5/mensaje.mp4","cover_path":"covers/day-5/portada.jpg"}
-- audio: {"description":"..","audio_path":"audio/day-3/cancion.mp3","cover_path":"covers/day-3/portada.jpg"}
```
La función solo firma las rutas que aparecen en el contenido de un día ya desbloqueado para un token válido.

## Despliegue en Vercel
1. Sube el proyecto a un repositorio de GitHub (el `vercel.json` ya incluye la reescritura de rutas).
2. En Vercel: Add New → Project → elige el repositorio (framework Vite, se detecta solo).
3. Variables de entorno: `VITE_SUPABASE_URL=https://sszhhxutvulpukiknrbb.supabase.co` y `VITE_SUPABASE_ANON_KEY=<clave publishable de Supabase>`.
4. Enlace de Claudia: `https://TU-DOMINIO.vercel.app/i/<token>`.
