/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        burdeos: { DEFAULT: '#651D32', dark: '#45101f', deep: '#2b0a14' },
        oro: { DEFAULT: '#D5AD64', light: '#ecd193' },
        marfil: '#F6EEDF', bosque: '#183C32', calido: '#FFFDF8', noche: '#171416'
      },
      fontFamily: {
        serif: ['"Cormorant Garamond"', 'Georgia', 'serif'],
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mano: ['Caveat', 'cursive']
      }
    }
  },
  plugins: []
}
