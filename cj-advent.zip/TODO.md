1. npm install && npm run build; corregir errores.
2. Ejecutar el SQL en Supabase y probar /i/<token> con fechas reales y simuladas.
3. Ejecutar 0002_storage.sql, desplegar sign-media y probar con archivos reales.
4. Día 25 + OUR MEMORIES + música ambiental.
5. /admin (login, editor, biblioteca, generar enlace).
6. PWA completa y offline.
7. Playwright y despliegue en Vercel (con autorización de Joan).
