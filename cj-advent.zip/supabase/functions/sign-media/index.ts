// Edge Function (Deno). Devuelve URLs firmadas SOLO para los archivos citados
// en el contenido de un día que el token ya puede abrir (publicado y desbloqueado).
import { createClient } from 'npm:@supabase/supabase-js@2.46.1'

const BUCKETS = ['covers', 'photos', 'videos', 'audio', 'music']
const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
}
const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...cors, 'Content-Type': 'application/json' } })

// Recoge rutas "bucket/objeto" de campos llamados path o *_path.
function collect(v: unknown, out: string[] = []): string[] {
  if (Array.isArray(v)) v.forEach(x => collect(x, out))
  else if (v && typeof v === 'object') {
    for (const [k, x] of Object.entries(v)) {
      if (typeof x === 'string' && (k === 'path' || k.endsWith('_path'))) out.push(x)
      else collect(x, out)
    }
  }
  return out
}

Deno.serve(async req => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  try {
    const { token, day } = await req.json()
    const url = Deno.env.get('SUPABASE_URL')!
    const anon = createClient(url, Deno.env.get('SUPABASE_ANON_KEY')!)
    const { data, error } = await anon.rpc('open_day', { p_token: token, p_day: day })
    if (error || !data?.length) return json({ error: 'not_available' }, 403)

    const admin = createClient(url, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)
    const urls: Record<string, string> = {}
    for (const p of collect(data[0].content)) {
      const i = p.indexOf('/')
      const bucket = p.slice(0, i), obj = p.slice(i + 1)
      if (i < 1 || !BUCKETS.includes(bucket) || obj.includes('..')) continue
      const { data: s } = await admin.storage.from(bucket).createSignedUrl(obj, 3600)
      if (s?.signedUrl) urls[p] = s.signedUrl
    }
    return json({ urls })
  } catch {
    return json({ error: 'bad_request' }, 400)
  }
})
