-- Buckets PRIVADOS. Los visitantes nunca leen Storage directamente:
-- reciben URLs firmadas (1 h) de la función sign-media, solo para archivos de un día ya desbloqueado.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
  ('covers', 'covers', false, 5242880,   array['image/jpeg','image/png','image/webp']),
  ('photos', 'photos', false, 10485760,  array['image/jpeg','image/png','image/webp']),
  ('videos', 'videos', false, 52428800,  array['video/mp4','video/webm']),
  ('audio',  'audio',  false, 31457280,  array['audio/mpeg','audio/mp4','audio/ogg','audio/wav']),
  ('music',  'music',  false, 31457280,  array['audio/mpeg','audio/mp4','audio/ogg'])
on conflict (id) do update set public = false,
  file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

create policy admin_media_all on storage.objects for all to authenticated
  using (bucket_id in ('covers','photos','videos','audio','music') and public.is_admin())
  with check (bucket_id in ('covers','photos','videos','audio','music') and public.is_admin());
