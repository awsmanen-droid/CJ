-- C&J ❤️ · esquema inicial. Ejecutar en el SQL Editor de Supabase (o con la CLI).
create extension if not exists pgcrypto with schema extensions;

create table public.advent_days (
  id uuid primary key default gen_random_uuid(),
  day_number int not null unique check (day_number between 1 and 25),
  title text not null default '',
  subtitle text,
  content_type text not null default 'letter'
    check (content_type in ('letter','gallery','video','audio','voucher','quiz','riddle','experience')),
  content jsonb not null default '{}'::jsonb,
  cover_path text,
  unlock_at timestamptz not null,
  is_published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Un token = un enlace privado. Solo se guarda el hash; visitor_id se mantiene al regenerar el enlace.
create table public.invite_tokens (
  id uuid primary key default gen_random_uuid(),
  token_hash text not null unique,
  visitor_id text not null default encode(extensions.gen_random_bytes(16), 'hex'),
  created_at timestamptz not null default now(),
  revoked_at timestamptz
);

create table public.user_progress (
  id uuid primary key default gen_random_uuid(),
  day_number int not null references public.advent_days(day_number) on delete cascade,
  visitor_id text not null,
  opened_at timestamptz not null default now(),
  redeemed_at timestamptz,
  constraint user_progress_visitor_day_key unique (visitor_id, day_number)
);

create table public.admin_users (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  role text not null default 'admin',
  created_at timestamptz not null default now()
);

create or replace function public.touch_updated_at() returns trigger
language plpgsql set search_path = '' as $$
begin new.updated_at = now(); return new; end $$;
create trigger advent_days_touch before update on public.advent_days
  for each row execute function public.touch_updated_at();

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.admin_users where user_id = auth.uid())
$$;

-- RLS: nadie anónimo toca las tablas. Solo el admin; el visitante entra por funciones.
alter table public.advent_days enable row level security;
alter table public.invite_tokens enable row level security;
alter table public.user_progress enable row level security;
alter table public.admin_users enable row level security;

revoke all on public.advent_days, public.invite_tokens, public.user_progress, public.admin_users from anon, authenticated;
grant select, insert, update, delete on public.advent_days to authenticated;
grant select on public.invite_tokens, public.user_progress, public.admin_users to authenticated;

create policy admin_all_days on public.advent_days for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
create policy admin_read_tokens on public.invite_tokens for select to authenticated using (public.is_admin());
create policy admin_read_progress on public.user_progress for select to authenticated using (public.is_admin());
create policy own_admin_row on public.admin_users for select to authenticated using (user_id = auth.uid());

-- Valida el token y devuelve el visitor_id. Interna: nadie puede llamarla desde la API.
create or replace function public._token_ok(p_token text) returns text
language plpgsql stable security definer set search_path = '' as $$
declare v text;
begin
  select t.visitor_id into v from public.invite_tokens t
   where t.token_hash = encode(extensions.digest(coalesce(p_token, ''), 'sha256'), 'hex')
     and t.revoked_at is null;
  if v is null then raise exception 'invalid_token' using errcode = '28000'; end if;
  return v;
end $$;

-- Estado de las 25 puertas SIN contenido. La hora la pone el servidor.
create or replace function public.get_calendar(p_token text)
returns table (day_number int, unlock_at timestamptz, available boolean, opened boolean)
language plpgsql stable security definer set search_path = '' as $$
declare h text := public._token_ok(p_token);
begin
  return query
    select d.day_number, d.unlock_at,
           (d.is_published and d.unlock_at <= now()),
           exists (select 1 from public.user_progress p where p.visitor_id = h and p.day_number = d.day_number)
      from public.advent_days d order by d.day_number;
end $$;

-- Devuelve el contenido solo si está publicado y desbloqueado; registra la apertura.
create or replace function public.open_day(p_token text, p_day int)
returns table (day_number int, title text, subtitle text, content_type text, content jsonb, redeemed boolean)
language plpgsql volatile security definer set search_path = '' as $$
declare h text := public._token_ok(p_token); d public.advent_days;
begin
  select * into d from public.advent_days a
   where a.day_number = p_day and a.is_published and a.unlock_at <= now();
  if not found then raise exception 'not_available' using errcode = '42501'; end if;
  insert into public.user_progress (day_number, visitor_id) values (p_day, h)
    on conflict on constraint user_progress_visitor_day_key do nothing;
  return query
    select d.day_number, d.title, d.subtitle, d.content_type, d.content,
           exists (select 1 from public.user_progress p
                    where p.visitor_id = h and p.day_number = d.day_number and p.redeemed_at is not null);
end $$;

create or replace function public.redeem_day(p_token text, p_day int) returns void
language plpgsql volatile security definer set search_path = '' as $$
declare h text := public._token_ok(p_token);
begin
  update public.user_progress set redeemed_at = coalesce(redeemed_at, now())
   where visitor_id = h and day_number = p_day;
end $$;

-- Solo admin: revoca el enlace anterior y devuelve uno nuevo (se muestra una única vez).
create or replace function public.create_invite_token() returns text
language plpgsql volatile security definer set search_path = '' as $$
declare t text; v text;
begin
  if not public.is_admin() then raise exception 'forbidden' using errcode = '42501'; end if;
  select visitor_id into v from public.invite_tokens order by created_at desc limit 1;
  update public.invite_tokens set revoked_at = now() where revoked_at is null;
  t := encode(extensions.gen_random_bytes(32), 'hex');
  insert into public.invite_tokens (token_hash, visitor_id)
    values (encode(extensions.digest(t, 'sha256'), 'hex'), coalesce(v, encode(extensions.gen_random_bytes(16), 'hex')));
  return t;
end $$;

revoke execute on function public._token_ok(text), public.get_calendar(text), public.open_day(text, int),
  public.redeem_day(text, int), public.create_invite_token(), public.is_admin() from public, anon, authenticated;
grant execute on function public.get_calendar(text), public.open_day(text, int), public.redeem_day(text, int) to anon, authenticated;
grant execute on function public.create_invite_token(), public.is_admin() to authenticated;
