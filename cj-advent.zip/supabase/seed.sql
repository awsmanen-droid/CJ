-- 25 días de DEMOSTRACIÓN. Sin texto personal: Joan lo sustituirá.
-- Publicados para poder probar; ponlos a false si prefieres borradores.
insert into public.advent_days (day_number, title, subtitle, content_type, content, unlock_at, is_published)
select n, 'Día ' || n, 'Contenido de demostración', t,
  case t
    when 'letter'  then '{"body":"Aquí irá tu sorpresa","signature":"Joan"}'::jsonb
    when 'voucher' then '{"description":"Aquí irá tu sorpresa","conditions":"Condiciones de demostración"}'::jsonb
    when 'quiz'    then '{"questions":[{"q":"Pregunta de demostración","options":["Respuesta A","Respuesta B"],"correct":0}],"final_message":"Aquí irá tu mensaje final"}'::jsonb
    when 'riddle'  then '{"text":"Aquí irá tu acertijo","hint":"Aquí irá la pista","answer":"respuesta","success_message":"¡Resuelto!"}'::jsonb
    else '{"description":"Aquí irá tu sorpresa"}'::jsonb
  end,
  make_timestamptz(2026, 12, n, 0, 0, 0, 'Europe/Madrid'), true
from generate_series(1, 25) as n,
lateral (select (array['letter','gallery','audio','letter','video','quiz','voucher','gallery','audio','gallery',
  'riddle','letter','audio','voucher','video','letter','quiz','riddle','letter','video',
  'gallery','letter','voucher','letter','experience'])[n] as t) x
on conflict (day_number) do nothing;
