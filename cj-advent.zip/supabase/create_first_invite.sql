-- Ejecutar UNA vez en el SQL Editor. Devuelve el token en claro: guárdalo, no se puede recuperar.
-- Enlace final: https://TU-DOMINIO/i/<token>
-- (Más adelante el panel /admin lo generará con create_invite_token().)
with t as (select encode(extensions.gen_random_bytes(32), 'hex') as tok),
     i as (insert into public.invite_tokens (token_hash)
           select encode(extensions.digest(tok, 'sha256'), 'hex') from t)
select tok from t;
