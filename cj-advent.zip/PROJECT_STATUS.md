# Estado del proyecto C&J ❤️

**Todo escrito pero SIN compilar ni probar** (el entorno donde se genera no tiene red). Primer paso: `npm install && npm run build`.

## Hecho
- Landing, calendario 5×5, estados de puerta, días especiales (24 y 25).
- Supabase (sin ejecutar aún): tablas, RLS, funciones con token hasheado y hora de servidor, seed de 25 días de demo.
- Capa `services/api.ts`: usa Supabase si hay variables de entorno; si no, modo demo.
- Sorpresas: carta, vale (con canje guardado), quiz, acertijo.
- Enlace privado `/i/<token>`.
- Galería (polaroid + lightbox), vídeo y audio con URLs firmadas (Edge Function `sign-media`, buckets privados). Sin ejecutar ni desplegar aún.

- Mejoras de UX: animación de apertura la primera vez, marca «Hoy», aviso al tocar un día bloqueado, barra de progreso, Esc y bloqueo de scroll, botón «Volver al calendario», entrada escalonada en la landing.

## Estado de Supabase (proyecto sszhhxutvulpukiknrbb)
- Aplicado por conector: migración de tablas, RLS y funciones; buckets privados; seed de 25 días de demostración; función `sign-media` (verify_jwt desactivado, se autentica con el token).
- NO hecho: token de invitación (ejecutar `supabase/create_first_invite.sql`), usuario admin, prueba de seguridad como visitante anónimo.

## Diseño
- Nuevo diseño portado desde la vista previa: portada con pueblo navideño, logo, casillas desordenadas con puerta que se queda abierta.

## Pendiente
- Día 25 (`experience`), reproductor de vídeo personalizado.
- Modo OUR MEMORIES, música ambiental, panel /admin, biblioteca multimedia.
- Service worker y offline. Tests (Playwright). Despliegue (Vercel).

## Límites conocidos
- La respuesta de un acertijo viaja con el contenido de ese día (se comprueba en el navegador).
- En modo demo no hay seguridad real.
