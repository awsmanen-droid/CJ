import { Route, Routes } from 'react-router-dom'
import Sprite from './components/Sprite'
import Welcome from './pages/Welcome'
import Calendar from './pages/Calendar'
import InviteRedirect from './pages/InviteRedirect'

export default function App() {
  return (
    <>
      <Sprite />
      <Routes>
        <Route path="/" element={<Welcome />} />
        <Route path="/calendario" element={<Calendar />} />
        <Route path="/i/:token" element={<InviteRedirect />} />
        <Route path="*" element={<Welcome />} />
      </Routes>
    </>
  )
}
