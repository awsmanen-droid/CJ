import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import Snow from '../components/Snow'
import Scene from '../components/Scene'
import Logo from '../components/Logo'
import { getNow, todayNumber, unlockAt } from '../utils/advent'

function useCountdown() {
  const [now, setNow] = useState(getNow())
  useEffect(() => {
    const t = setInterval(() => setNow(getNow()), 1000)
    return () => clearInterval(t)
  }, [])
  const ms = Math.max(0, unlockAt(1) - now)
  const s = Math.floor(ms / 1000)
  return { done: ms === 0, today: todayNumber(now), d: Math.floor(s / 86400), h: Math.floor(s / 3600) % 24, m: Math.floor(s / 60) % 60, s: s % 60 }
}

export default function Welcome() {
  const c = useCountdown()
  const units: [number, string][] = [[c.d, 'días'], [c.h, 'horas'], [c.m, 'min'], [c.s, 'seg']]
  return (
    <main id="landing">
      <Snow />
      <div className="hero">
        <Logo className="logo-big" />
        <p className="eyebrow">Calendario de Adviento</p>
        <h1>25 pequeñas sorpresas para ti</h1>
        <p className="sub">Hecho con mucho amor y pensado para ti</p>
        {c.done ? (
          <p className="sub" style={{ color: 'var(--marfil)' }}>
            {c.today >= 25 ? 'Ya están todas tus sorpresas' : `Hoy te espera el día ${c.today}`}
          </p>
        ) : (
          <div className="cd" role="timer" aria-label="Cuenta atrás hasta el 1 de diciembre">
            {units.map(([v, l]) => (
              <div key={l}><b>{String(v).padStart(2, '0')}</b><small>{l}</small></div>
            ))}
          </div>
        )}
        <Link to="/calendario" className="btn">Mira el calendario</Link>
      </div>
      <Scene />
    </main>
  )
}
