import { useEffect, useMemo, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import Snow from '../components/Snow'
import Logo from '../components/Logo'
import Tile from '../components/Tile'
import SurpriseRenderer from '../components/surprises/SurpriseRenderer'
import { getCalendar, hasAccess, isDemo, openDay } from '../services/api'
import type { CalendarDay, Surprise } from '../services/types'
import { TOTAL, SPECIAL_DAYS, getNow, todayNumber } from '../utils/advent'
import { DAY_AT, TILES } from '../utils/layout'

export default function Calendar() {
  const [days, setDays] = useState<CalendarDay[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [active, setActive] = useState<number | null>(null)
  const [surprise, setSurprise] = useState<Surprise | null>(null)
  const [openErr, setOpenErr] = useState<string | null>(null)
  const [toast, setToast] = useState<string | null>(null)
  const toastTimer = useRef<number>()
  const today = useMemo(() => todayNumber(getNow()), [])

  useEffect(() => {
    if (!hasAccess()) { setError('Necesitas tu enlace privado para entrar. Pídeselo a Joan.'); return }
    getCalendar().then(setDays).catch(() => setError('No se pudo cargar el calendario. Comprueba la conexión y recarga.'))
  }, [])

  const close = () => setActive(null)
  useEffect(() => {
    if (active === null) return
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') close() }
    window.addEventListener('keydown', onKey)
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => { window.removeEventListener('keydown', onKey); document.body.style.overflow = prev }
  }, [active])

  const setOpened = (day: number, opened: boolean) =>
    setDays(ds => ds && ds.map(d => (d.day_number === day ? { ...d, opened } : d)))

  const show = async (day: number, first: boolean) => {
    setActive(day); setSurprise(null); setOpenErr(null)
    navigator.vibrate?.(30)
    try {
      setSurprise(await openDay(day))
    } catch {
      setOpenErr('Esta sorpresa todavía no está disponible.')
      if (first) setOpened(day, false)
    }
  }

  // La puerta se abre y se queda abierta; después aparece la sorpresa.
  const activate = (day: number) => {
    const first = !days?.find(d => d.day_number === day)?.opened
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    if (first) setOpened(day, true)
    window.setTimeout(() => show(day, first), first && !reduce ? 700 : 0)
  }

  const locked = (day: number) => {
    setToast(day === today + 1 ? 'Mañana se abre este día' : `Este día se abre el ${day} de diciembre`)
    window.clearTimeout(toastTimer.current)
    toastTimer.current = window.setTimeout(() => setToast(null), 2500)
  }

  const byDay = new Map(days?.map(d => [d.day_number, d]))
  const started = !!days?.some(d => d.available)
  const openedCount = days?.filter(d => d.opened).length ?? 0

  return (
    <main id="calendar">
      <Snow count={25} />
      <Link to="/" className="back">← Inicio</Link>
      <div className="cal">
        <div className="panel">
          <Logo className="logo-sm" />
          <h2>Nuestro calendario</h2>
          {error ? (
            <p role="alert" className="sub">{error}</p>
          ) : (
            <>
              <p className="sub">{started ? 'Busca las puertas doradas' : 'Una vista previa: se abrirá el 1 de diciembre'}</p>
              {started && today < TOTAL && <p id="hint">Mañana se abre el día {today + 1}</p>}
              {started && (
                <div className="prog">
                  <div><i style={{ width: `${(openedCount / TOTAL) * 100}%` }} /></div>
                  <small>{openedCount} de {TOTAL} sorpresas abiertas</small>
                </div>
              )}
              {isDemo && <p id="hint">Modo demostración (sin Supabase)</p>}
            </>
          )}
        </div>
        {!error && (
          <div className="board">
            {TILES.map(([c, r, w, h, color], i) => {
              const day = DAY_AT[i], d = byDay.get(day)
              const state = d?.opened ? 'open' : d?.available ? 'avail' : 'closed'
              return (
                <Tile key={day} day={day} c={c} r={r} w={w} h={h} color={color} state={state}
                  today={day === today} special={SPECIAL_DAYS.includes(day)} onActivate={activate} onLocked={locked} />
              )
            })}
          </div>
        )}
      </div>

      <div id="toast" className={toast ? 'on' : ''} role="status" aria-live="polite">{toast}</div>
      <div id="modal" className={active !== null ? 'on' : ''} role="dialog" aria-modal="true" aria-label={`Día ${active ?? ''}`}
        onClick={e => { if (e.target === e.currentTarget) close() }}>
        {active !== null && (
          <div className="card">
            {openErr ? <p role="alert" className="font-mano text-2xl">{openErr}</p>
              : surprise ? <SurpriseRenderer key={surprise.day_number} s={surprise} />
              : <p className="font-mano text-2xl">Abriendo…</p>}
            <button className="close" onClick={close} autoFocus>Volver al calendario</button>
          </div>
        )}
      </div>
    </main>
  )
}
