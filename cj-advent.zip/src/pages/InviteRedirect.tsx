import { useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { setToken } from '../services/api'

export default function InviteRedirect() {
  const { token } = useParams()
  const navigate = useNavigate()
  useEffect(() => {
    if (token) setToken(token)
    navigate('/', { replace: true }) // quita el token de la barra de direcciones
  }, [token, navigate])
  return null
}
