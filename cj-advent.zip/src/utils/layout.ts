// Rejilla de 6 columnas × 10 filas. [columna, fila, ancho, alto, color]
export const TILES: [number, number, number, number, string][] = [
  [1,1,2,3,'red'],[3,1,2,2,'coral'],[5,1,2,2,'cream'],[3,3,2,1,'mint'],[5,3,2,2,'red'],
  [1,4,2,2,'mint'],[3,4,2,1,'coral'],[3,5,1,1,'cream'],[4,5,1,1,'red'],[5,5,2,1,'mint'],
  [1,6,3,2,'cream'],[4,6,1,2,'coral'],[5,6,2,2,'red'],[1,8,2,2,'mint'],[3,8,2,1,'red'],
  [5,8,1,1,'coral'],[6,8,1,1,'cream'],[3,9,1,1,'mint'],[4,9,1,1,'coral'],[5,9,2,1,'cream'],
  [1,10,2,1,'coral'],[3,10,1,1,'red'],[4,10,1,1,'mint'],[5,10,1,1,'cream'],[6,10,1,1,'red']
]
// Día de cada casilla, mezclados a propósito para que haya que buscarlos.
export const DAY_AT = [25,19,3,12,7,1,16,9,22,5,24,2,14,18,10,21,6,13,4,20,11,17,8,23,15]
// Dibujo de cada día (índice = día).
export const MOTIF = ['', 'candle','mitten','envelope','bell','mistle','cane','ornament','sock','key','snowflake','mug','wreath','ring','star','heart','gift','tree','envelope','candle','mistle','cane','heart','mug','gift','tree']
