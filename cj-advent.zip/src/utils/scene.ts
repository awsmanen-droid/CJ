// Pueblo navideño de la portada: genera el SVG como texto.
const R = (a: number, b: number) => a + Math.random() * (b - a)

export function buildScene(): string {
  const HP = 'M0 7C-14-3-9-12 0-6C9-12 14-3 0 7Z';
  const tree = (x: number, y: number, h: number): string => {
    const w = h * .4; let s = `<g transform="translate(${x} ${y})" filter="url(#sh)">`;
    for (let i = 0; i < 4; i++) {
      const t = -h + i * h * .21, tw = w * (.42 + i * .2), th = h * .4;
      s += `<path d="M0 ${t}L${tw} ${t + th}Q0 ${t + th + 6} ${-tw} ${t + th}Z" fill="url(#fir)"/><path d="M0 ${t}L${tw * .5} ${t + th * .5}Q0 ${t + th * .42} ${-tw * .5} ${t + th * .5}Z" fill="#f6eedf" opacity=".92"/>`;
      for (let k = 0; k < 2; k++) s += `<circle class="tw" style="animation-delay:${R(0, 3).toFixed(1)}s" cx="${R(-tw * .6, tw * .6).toFixed(0)}" cy="${(t + th * R(.55, .9)).toFixed(0)}" r="3" fill="${['#ffd98a', '#ff7a6a', '#fff'][(i + k) % 3]}"/>`;
    }
    return s + '<rect x="-5" y="-2" width="10" height="10" fill="#5b3a2a"/></g>';
  };
  const house = (x: number, y: number, w: number, h: number, spire?: number | boolean): string => {
    const rh = h * .7, cx = w / 2, nw = w > 140 ? 4 : 2; let s = `<g transform="translate(${x} ${y})" filter="url(#sh)"><rect x="0" y="${-h}" width="${w}" height="${h}" rx="4" fill="url(#wall)"/>`;
    for (let i = 0; i < nw; i++) { const wx = w * (i + .5) / nw - 12, wy = -h + h * .32; s += `<rect x="${wx}" y="${wy}" width="24" height="32" rx="3" fill="url(#glow)" stroke="#3a2418" stroke-width="3"/><path d="M${wx + 12} ${wy}v32M${wx} ${wy + 16}h24" stroke="#3a2418" stroke-width="2"/>`; }
    s += `<path d="M${cx - 14} 0V-34a14 14 0 0 1 28 0V0Z" fill="#7a2a22" stroke="#3a2418" stroke-width="3"/><rect x="${w * .72}" y="${-h - rh * .62}" width="16" height="32" fill="#8a3f2d"/><rect x="${w * .72 - 3}" y="${-h - rh * .62 - 5}" width="22" height="8" rx="4" fill="url(#snow)"/>`;
    if (spire) s += `<rect x="${w - 52}" y="${-h - 70}" width="52" height="72" fill="url(#wall)"/><path d="M${w - 60} ${-h - 64}L${w - 26} ${-h - 150}L${w + 8} ${-h - 64}Z" fill="#d97a5a" stroke="#c4623f" stroke-width="4" stroke-linejoin="round"/><path d="M${w - 52} ${-h - 70}L${w - 26} ${-h - 140}L${w} ${-h - 70}Q${w - 26} ${-h - 80} ${w - 52} ${-h - 70}Z" fill="url(#snow)"/><path d="${HP}" transform="translate(${w - 26} ${-h - 36}) scale(2)" fill="url(#glow)" stroke="#3a2418" stroke-width="1.5"/>`;
    s += `<path d="M-14 ${-h + 8}L${cx} ${-h - rh}L${w + 14} ${-h + 8}Z" fill="url(#snow)" stroke="#c4623f" stroke-width="5" stroke-linejoin="round"/>`;
    for (let k = -10; k < w + 14; k += 18) s += `<circle cx="${k}" cy="${-h + 8}" r="9" fill="url(#snow)"/>`;
    return s + `<path d="${HP}" transform="translate(${cx} ${-h - rh * .36}) scale(1.7)" fill="url(#glow)" stroke="#c4623f" stroke-width="1.5"/></g>`;
  };
  const bola = (x: number, len: number, r: number, g: string, heart?: number | boolean): string => `<g class="sway" style="transform-origin:${x}px 0px;animation-delay:-${R(0, 4).toFixed(1)}s"><path d="M${x} 0V${len}" stroke="#d5ad64" stroke-width="1.5"/>` +
    (heart ? `<path d="${HP}" transform="translate(${x} ${len + r}) scale(${r / 8})" fill="url(#${g})" filter="url(#sh)"/>`
      : `<circle cx="${x}" cy="${len + r}" r="${r}" fill="url(#${g})" filter="url(#sh)"/><rect x="${x - r * .3}" y="${len - 3}" width="${r * .6}" height="7" rx="2" fill="#d5ad64"/>`) + '</g>';
  let garland = '<path d="M170 30Q600 190 1030 30" fill="none" stroke="#d5ad64" stroke-width="1.5" opacity=".7"/>';
  for (let i = 0; i <= 12; i++) { const t = i / 12, u = 1 - t, x = u * u * 170 + 2 * u * t * 600 + t * t * 1030, y = u * u * 30 + 2 * u * t * 190 + t * t * 30;
    garland += `<path class="tw" style="animation-delay:${(i * .3) % 3}s" d="${HP}" transform="translate(${x.toFixed(0)} ${(y + 8).toFixed(0)}) scale(1.15)" fill="${['#ff6b6b', '#ffd98a', '#fff3c4', '#ff9a6a'][i % 4]}"/>`; }
  const sky = Array.from({ length: 24 }, () => `<circle class="tw" style="animation-delay:${R(0, 3).toFixed(1)}s" cx="${R(0, 1200).toFixed(0)}" cy="${R(10, 340).toFixed(0)}" r="${R(.8, 2).toFixed(1)}" fill="#fff"/>`).join('');
  let ledge = 'M0 392H1200V412'; for (let x = 1200; x > 0; x -= 40) ledge += 'q-20 36 -40 0'; ledge += 'Z';
  return `<defs>
  <linearGradient id="fir" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3f8a6d"/><stop offset="1" stop-color="#143b2f"/></linearGradient>
  <linearGradient id="snow" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fffdf8"/><stop offset="1" stop-color="#e6d9c0"/></linearGradient>
  <linearGradient id="wall" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#a87552"/><stop offset="1" stop-color="#5e3b2c"/></linearGradient>
  <radialGradient id="glow"><stop offset="0" stop-color="#fff0b8"/><stop offset=".6" stop-color="#ffb347"/><stop offset="1" stop-color="#ff7a3d"/></radialGradient>
  <radialGradient id="bR" cx=".35" cy=".3" r=".8"><stop offset="0" stop-color="#ffb3a6"/><stop offset=".45" stop-color="#d63447"/><stop offset="1" stop-color="#651D32"/></radialGradient>
  <radialGradient id="bG" cx=".35" cy=".3" r=".8"><stop offset="0" stop-color="#fff6cf"/><stop offset=".5" stop-color="#d5ad64"/><stop offset="1" stop-color="#8a6a2c"/></radialGradient>
  <filter id="sh" x="-20%" y="-20%" width="140%" height="150%"><feDropShadow dx="0" dy="6" stdDeviation="5" flood-color="#000" flood-opacity=".45"/></filter></defs>
  <g>${sky}</g>
  <g class="par" data-k="6">${[60, 150, 250, 340, 520, 700, 860, 960, 1060, 1150].map((x, i) => tree(x, 388, [150, 120, 170, 130, 140, 120, 160, 130, 175, 140][i])).join('')}</g>
  <g class="par" data-k="10">${garland}</g>
  <g class="par" data-k="14">${house(270, 392, 180, 110)}${house(560, 392, 110, 80)}${house(730, 392, 210, 125, 1)}</g>
  <g class="par" data-k="24"><path d="${ledge}" fill="url(#snow)" filter="url(#sh)"/>${[[85, 230], [215, 170], [500, 150], [700, 130], [990, 210], [1130, 190]].map(([x, h]) => tree(x, 418, h)).join('')}</g>
  <g class="par" data-k="34">${bola(120, 90, 24, 'bR')}${bola(335, 40, 15, 'bG')}${bola(640, 70, 20, 'bR', 1)}${bola(1085, 120, 28, 'bG', 1)}${bola(1005, 40, 14, 'bR')}</g>`;
}
