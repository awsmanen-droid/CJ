// Fechas oficiales en Europe/Madrid. En diciembre Madrid es UTC+1, así que
// las 00:00 locales del día N son las 23:00 UTC del día N-1.
// ⚠ Esta lógica es solo visual. La validación real irá en Supabase (fase 3).
export const YEAR = 2026
export const TOTAL = 25
export const SPECIAL_DAYS = [24, 25]

export const unlockAt = (day: number) => Date.UTC(YEAR, 11, day, -1)

export type DoorState = 'closed' | 'available' | 'opened'

export function getNow(): number {
  // En desarrollo: http://localhost:5173/?fecha=2026-12-05 simula esa fecha.
  if (import.meta.env.DEV) {
    const p = new URLSearchParams(location.search).get('fecha')
    const m = p && /^(\d{4})-(\d{2})-(\d{2})$/.exec(p)
    if (m) return Date.UTC(+m[1], +m[2] - 1, +m[3], -1, 0, 1)
  }
  return Date.now()
}

export const doorState = (day: number, now: number, opened: number[]): DoorState =>
  now < unlockAt(day) ? 'closed' : opened.includes(day) ? 'opened' : 'available'

const KEY = 'cj-opened'
export const loadOpened = (): number[] => {
  try { return JSON.parse(localStorage.getItem(KEY) ?? '[]') } catch { return [] }
}
export const saveOpened = (list: number[]) => {
  try { localStorage.setItem(KEY, JSON.stringify(list)) } catch { /* sin almacenamiento */ }
}

/** Último día ya desbloqueado por fecha (0 si aún no empieza). Solo para la interfaz. */
export const todayNumber = (now: number): number => {
  let n = 0
  for (let d = 1; d <= TOTAL; d++) if (now >= unlockAt(d)) n = d
  return n
}
