import { useEffect, useMemo } from 'react'
import { buildScene } from '../utils/scene'

export default function Scene() {
  const html = useMemo(buildScene, [])
  // Parallax suave con el ratón (solo ordenador y sin «reducir movimiento»).
  useEffect(() => {
    if (matchMedia('(prefers-reduced-motion: reduce)').matches || !matchMedia('(pointer:fine)').matches) return
    const groups = Array.from(document.querySelectorAll<SVGGElement>('#scene .par'))
    const move = (e: PointerEvent) => {
      const x = e.clientX / innerWidth - 0.5, y = e.clientY / innerHeight - 0.5
      groups.forEach(g => {
        const k = Number(g.dataset.k)
        g.style.transform = `translate(${(-x * k).toFixed(1)}px,${(-y * k * 0.5).toFixed(1)}px)`
      })
    }
    addEventListener('pointermove', move)
    return () => removeEventListener('pointermove', move)
  }, [])
  return (
    <div id="scene-wrap">
      <svg id="scene" viewBox="0 0 1200 460" preserveAspectRatio="xMidYMax slice" aria-hidden="true"
        dangerouslySetInnerHTML={{ __html: html }} />
    </div>
  )
}
