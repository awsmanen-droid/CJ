import { useMemo } from 'react'

export default function Snow({ count = 40 }: { count?: number }) {
  const flakes = useMemo(() => Array.from({ length: count }, (_, i) => ({
    id: i, left: Math.random() * 100, size: 2 + Math.random() * 4,
    dur: 9 + Math.random() * 12, delay: -Math.random() * 20
  })), [count])
  return (
    <div className="snow" aria-hidden="true">
      {flakes.map(f => (
        <span key={f.id} className="flake" style={{
          left: `${f.left}%`, width: f.size, height: f.size,
          animationDuration: `${f.dur}s`, animationDelay: `${f.delay}s`
        }} />
      ))}
    </div>
  )
}
