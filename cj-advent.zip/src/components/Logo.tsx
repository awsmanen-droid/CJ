export default function Logo({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 120 120" role="img" aria-label="Logotipo C&J">
      <use href="#logo" width="120" height="120" />
    </svg>
  )
}
