import { useState } from 'react'
import { motion } from 'framer-motion'
import { Gift } from 'lucide-react'
import type { Surprise } from '../../services/types'
import { redeem } from '../../services/api'

export default function VoucherSurprise({ s }: { s: Surprise }) {
  const [done, setDone] = useState(s.redeemed)
  const [err, setErr] = useState(false)
  const c = s.content as { description?: string; conditions?: string }
  const onRedeem = async () => {
    try { await redeem(s.day_number); setDone(true); setErr(false) } catch { setErr(true) }
  }
  return (
    <div>
      <motion.div initial={{ rotate: -3, scale: 0.9 }} animate={{ rotate: 0, scale: 1 }} transition={{ type: 'spring' }}
        className="rounded-lg border-2 border-dashed border-oro bg-calido p-6">
        <Gift className="mx-auto h-8 w-8 text-burdeos" />
        <h2 className="mt-2 font-serif text-3xl font-semibold text-burdeos">{s.title}</h2>
        <p className="mt-3 font-mano text-2xl">{c.description}</p>
        {c.conditions && <p className="mt-3 text-xs text-burdeos-deep/60">{c.conditions}</p>}
      </motion.div>
      <button onClick={onRedeem} disabled={done}
        className="mt-5 rounded-full bg-burdeos px-6 py-2 font-serif text-lg text-marfil disabled:bg-bosque">
        {done ? 'Canjeado' : 'Marcar como canjeado'}
      </button>
      {err && <p role="alert" className="mt-2 text-sm text-burdeos">No se pudo guardar. Inténtalo de nuevo.</p>}
    </div>
  )
}
