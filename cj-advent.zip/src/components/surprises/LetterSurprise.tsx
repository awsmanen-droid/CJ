import { useState } from 'react'
import { motion } from 'framer-motion'
import { Heart } from 'lucide-react'
import type { Surprise } from '../../services/types'

export default function LetterSurprise({ s }: { s: Surprise }) {
  const [open, setOpen] = useState(false)
  const c = s.content as { body?: string; signature?: string; date?: string }
  if (!open) {
    return (
      <button onClick={() => setOpen(true)} className="group mx-auto block w-full">
        <motion.div whileHover={{ y: -3 }} className="relative mx-auto h-36 w-56 rounded-md border border-oro/60 bg-calido shadow-lg">
          <div className="absolute inset-x-0 top-0 h-20 origin-top [clip-path:polygon(0_0,100%_0,50%_100%)] bg-marfil border-b border-oro/40" />
          <span className="absolute left-1/2 top-12 flex h-10 w-10 -translate-x-1/2 items-center justify-center rounded-full bg-burdeos shadow">
            <Heart className="h-5 w-5 text-oro" fill="currentColor" />
          </span>
        </motion.div>
        <p className="mt-4 font-mano text-2xl">Abrir la carta</p>
      </button>
    )
  }
  return (
    <motion.article initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }} className="text-left">
      <h2 className="font-serif text-3xl font-semibold text-burdeos">{s.title}</h2>
      {c.date && <p className="text-xs text-burdeos-deep/60">{c.date}</p>}
      <div className="mt-4 whitespace-pre-line font-mano text-2xl leading-snug">{c.body}</div>
      {c.signature && <p className="mt-6 text-right font-mano text-2xl text-burdeos">{c.signature}</p>}
    </motion.article>
  )
}
