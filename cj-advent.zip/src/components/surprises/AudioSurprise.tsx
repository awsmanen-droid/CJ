import { useRef, useState } from 'react'
import { Pause, Play, Volume2 } from 'lucide-react'
import type { Surprise } from '../../services/types'

const fmt = (t: number) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, '0')}`

export default function AudioSurprise({ s }: { s: Surprise }) {
  const ref = useRef<HTMLAudioElement>(null)
  const [playing, setPlaying] = useState(false)
  const [time, setTime] = useState(0)
  const [dur, setDur] = useState(0)
  const [failed, setFailed] = useState(false)
  const src = s.media?.[s.content.audio_path]
  const cover = s.content.cover_path ? s.media?.[s.content.cover_path] : undefined

  const toggle = () => {
    const a = ref.current
    if (!a) return
    if (a.paused) a.play().catch(() => setFailed(true))
    else a.pause()
  }
  return (
    <div>
      <h2 className="font-serif text-3xl font-semibold text-burdeos">{s.title}</h2>
      {s.content.description && <p className="mt-3 font-mano text-2xl">{s.content.description}</p>}
      {!src || failed ? (
        <p role="alert" className="mt-4 text-sm text-burdeos-deep/60">
          {failed ? 'No se pudo reproducir el audio.' : 'El audio aún no está disponible.'}
        </p>
      ) : (
        <div className="mt-4 rounded-lg bg-calido p-4">
          {cover && <img src={cover} alt="" className="mx-auto mb-3 h-40 w-40 rounded-md object-cover" />}
          <audio ref={ref} src={src} preload="metadata"
            onPlay={() => setPlaying(true)} onPause={() => setPlaying(false)} onEnded={() => setPlaying(false)}
            onTimeUpdate={e => setTime(e.currentTarget.currentTime)}
            onLoadedMetadata={e => setDur(e.currentTarget.duration)} onError={() => setFailed(true)} />
          <div className="flex items-center gap-3">
            <button onClick={toggle} aria-label={playing ? 'Pausar' : 'Reproducir'}
              className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-burdeos text-marfil">
              {playing ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
            </button>
            <input type="range" min={0} max={dur || 0} step={0.1} value={time} aria-label="Progreso"
              onChange={e => { if (ref.current) ref.current.currentTime = +e.target.value }} className="w-full accent-burdeos" />
            <span className="w-10 text-xs tabular-nums">{fmt(time)}</span>
          </div>
          <div className="mt-3 flex items-center gap-2">
            <Volume2 className="h-4 w-4" aria-hidden />
            <input type="range" min={0} max={1} step={0.05} defaultValue={1} aria-label="Volumen"
              onChange={e => { if (ref.current) ref.current.volume = +e.target.value }} className="w-24 accent-burdeos" />
          </div>
        </div>
      )}
    </div>
  )
}
