import { useState, type FormEvent } from 'react'
import { motion } from 'framer-motion'
import type { Surprise } from '../../services/types'

const norm = (t: string) => t.normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim().toLowerCase()

// Nota: la respuesta viaja con el contenido (solo se desbloquea el día correspondiente).
export default function RiddleSurprise({ s }: { s: Surprise }) {
  const c = s.content as { text?: string; hint?: string; answer?: string; success_message?: string }
  const [value, setValue] = useState('')
  const [wrong, setWrong] = useState(false)
  const [hint, setHint] = useState(false)
  const [solved, setSolved] = useState(false)

  const submit = (e: FormEvent) => {
    e.preventDefault()
    if (norm(value) === norm(c.answer ?? '')) setSolved(true)
    else setWrong(true)
  }
  if (solved) {
    return (
      <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}>
        <h2 className="font-serif text-3xl font-semibold text-burdeos">{s.title}</h2>
        <p className="mt-4 font-mano text-2xl">{c.success_message}</p>
      </motion.div>
    )
  }
  return (
    <form onSubmit={submit}>
      <h2 className="font-serif text-3xl font-semibold text-burdeos">{s.title}</h2>
      <p className="mt-4 font-mano text-2xl">{c.text}</p>
      <input value={value} onChange={e => { setValue(e.target.value); setWrong(false) }} aria-label="Tu respuesta"
        className="mt-4 w-full rounded-md border border-burdeos/30 bg-calido px-3 py-2" />
      {wrong && <p role="alert" className="mt-2 text-sm text-burdeos">Esa no es. Prueba otra vez.</p>}
      <div className="mt-4 flex items-center justify-center gap-4">
        <button type="submit" className="rounded-full bg-burdeos px-6 py-2 font-serif text-lg text-marfil">Responder</button>
        {c.hint && <button type="button" onClick={() => setHint(true)} className="text-sm underline">Pedir pista</button>}
      </div>
      {hint && <p className="mt-3 text-sm italic">{c.hint}</p>}
    </form>
  )
}
