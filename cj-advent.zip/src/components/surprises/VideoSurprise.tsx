import { useState } from 'react'
import type { Surprise } from '../../services/types'

export default function VideoSurprise({ s }: { s: Surprise }) {
  const [failed, setFailed] = useState(false)
  const src = s.media?.[s.content.video_path]
  const poster = s.content.cover_path ? s.media?.[s.content.cover_path] : undefined
  return (
    <div>
      <h2 className="font-serif text-3xl font-semibold text-burdeos">{s.title}</h2>
      {s.content.description && <p className="mt-3 font-mano text-2xl">{s.content.description}</p>}
      {src && !failed ? (
        // Reproductor nativo por ahora; el personalizado llegará más adelante.
        <video className="mt-4 w-full rounded-md bg-black" src={src} poster={poster} controls playsInline
          preload="metadata" onError={() => setFailed(true)} />
      ) : (
        <p role="alert" className="mt-4 text-sm text-burdeos-deep/60">
          {failed ? 'No se pudo cargar el vídeo. Comprueba la conexión y vuelve a abrirlo.' : 'El vídeo aún no está disponible.'}
        </p>
      )}
    </div>
  )
}
