import { useState } from 'react'
import type { Surprise } from '../../services/types'

type Q = { q: string; options: string[]; correct?: number }

export default function QuizSurprise({ s }: { s: Surprise }) {
  const qs = (s.content.questions ?? []) as Q[]
  const [i, setI] = useState(0)
  const [picked, setPicked] = useState<number | null>(null)
  const [score, setScore] = useState(0)

  if (i >= qs.length) {
    const scored = qs.some(q => q.correct !== undefined)
    return (
      <div>
        <h2 className="font-serif text-3xl font-semibold text-burdeos">{s.title}</h2>
        {scored && <p className="mt-3 font-serif text-2xl">{score} de {qs.length}</p>}
        <p className="mt-3 font-mano text-2xl">{s.content.final_message}</p>
      </div>
    )
  }
  const q = qs[i]
  const choose = (n: number) => {
    if (picked !== null) return
    setPicked(n)
    if (q.correct === n) setScore(x => x + 1)
  }
  const cls = (n: number) => {
    if (picked === null) return 'border-burdeos/30 hover:bg-oro/20'
    if (q.correct === undefined) return n === picked ? 'border-oro bg-oro/30' : 'border-burdeos/20 opacity-60'
    if (n === q.correct) return 'border-bosque bg-bosque/15'
    return n === picked ? 'border-burdeos bg-burdeos/15' : 'border-burdeos/20 opacity-60'
  }
  return (
    <div>
      <p className="text-xs text-burdeos-deep/60">Pregunta {i + 1} de {qs.length}</p>
      <h2 className="mt-2 font-serif text-2xl font-semibold">{q.q}</h2>
      <div className="mt-4 flex flex-col gap-2">
        {q.options.map((o, n) => (
          <button key={n} onClick={() => choose(n)} className={`rounded-md border px-4 py-2 text-left transition ${cls(n)}`}>{o}</button>
        ))}
      </div>
      {picked !== null && (
        <button onClick={() => { setI(i + 1); setPicked(null) }} className="mt-5 rounded-full bg-burdeos px-6 py-2 font-serif text-lg text-marfil">
          {i + 1 === qs.length ? 'Ver resultado' : 'Siguiente'}
        </button>
      )}
    </div>
  )
}
