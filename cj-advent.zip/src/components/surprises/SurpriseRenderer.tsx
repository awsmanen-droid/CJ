import type { Surprise } from '../../services/types'
import LetterSurprise from './LetterSurprise'
import VoucherSurprise from './VoucherSurprise'
import QuizSurprise from './QuizSurprise'
import RiddleSurprise from './RiddleSurprise'
import GallerySurprise from './GallerySurprise'
import VideoSurprise from './VideoSurprise'
import AudioSurprise from './AudioSurprise'

export default function SurpriseRenderer({ s }: { s: Surprise }) {
  switch (s.content_type) {
    case 'letter': return <LetterSurprise s={s} />
    case 'voucher': return <VoucherSurprise s={s} />
    case 'quiz': return <QuizSurprise s={s} />
    case 'riddle': return <RiddleSurprise s={s} />
    case 'gallery': return <GallerySurprise s={s} />
    case 'video': return <VideoSurprise s={s} />
    case 'audio': return <AudioSurprise s={s} />
    default:
      // experience (día 25) llega en la siguiente fase.
      return (
        <div>
          <h2 className="font-serif text-3xl font-semibold text-burdeos">{s.title}</h2>
          <p className="mt-4 font-mano text-2xl">{s.content.description ?? 'Aquí irá tu sorpresa'}</p>
          <p className="mt-3 text-xs text-burdeos-deep/60">Tipo «{s.content_type}»: pendiente de implementar.</p>
        </div>
      )
  }
}
