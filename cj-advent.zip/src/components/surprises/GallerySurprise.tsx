import { useEffect, useState } from 'react'
import { createPortal } from 'react-dom'
import { ChevronLeft, ChevronRight, X } from 'lucide-react'
import type { Surprise } from '../../services/types'

type Photo = { path: string; caption?: string }

export default function GallerySurprise({ s }: { s: Surprise }) {
  const photos = ((s.content.photos ?? []) as Photo[]).filter(p => s.media?.[p.path])
  const [idx, setIdx] = useState<number | null>(null)

  useEffect(() => {
    if (idx === null) return
    const k = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setIdx(null)
      if (e.key === 'ArrowRight') setIdx(i => (i === null ? i : (i + 1) % photos.length))
      if (e.key === 'ArrowLeft') setIdx(i => (i === null ? i : (i + photos.length - 1) % photos.length))
    }
    window.addEventListener('keydown', k)
    return () => window.removeEventListener('keydown', k)
  }, [idx, photos.length])

  return (
    <div>
      <h2 className="font-serif text-3xl font-semibold text-burdeos">{s.title}</h2>
      {s.content.description && <p className="mt-3 font-mano text-2xl">{s.content.description}</p>}
      {photos.length === 0 ? (
        <p className="mt-4 text-sm text-burdeos-deep/60">Las fotografías aún no están disponibles.</p>
      ) : (
        <div className="mt-5 grid grid-cols-2 gap-4">
          {photos.map((p, i) => (
            <button key={p.path} onClick={() => setIdx(i)} aria-label={p.caption ?? `Foto ${i + 1}`}
              className="bg-calido p-2 pb-6 shadow-md transition hover:scale-105"
              style={{ transform: `rotate(${i % 2 ? 2 : -2}deg)` }}>
              <img src={s.media![p.path]} alt={p.caption ?? ''} loading="lazy" className="aspect-square w-full object-cover" />
              {p.caption && <span className="mt-1 block font-mano text-lg leading-none">{p.caption}</span>}
            </button>
          ))}
        </div>
      )}
      {idx !== null && createPortal(
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4" role="dialog" aria-modal="true" onClick={() => setIdx(null)}>
          <button aria-label="Cerrar" className="absolute right-4 top-4 text-marfil"><X /></button>
          <button aria-label="Anterior" className="absolute left-2 text-marfil" onClick={e => { e.stopPropagation(); setIdx((idx + photos.length - 1) % photos.length) }}><ChevronLeft className="h-10 w-10" /></button>
          <figure onClick={e => e.stopPropagation()} className="max-h-full text-center">
            <img src={s.media![photos[idx].path]} alt={photos[idx].caption ?? ''} className="max-h-[80vh] max-w-full object-contain" />
            {photos[idx].caption && <figcaption className="mt-2 font-mano text-2xl text-marfil">{photos[idx].caption}</figcaption>}
          </figure>
          <button aria-label="Siguiente" className="absolute right-2 text-marfil" onClick={e => { e.stopPropagation(); setIdx((idx + 1) % photos.length) }}><ChevronRight className="h-10 w-10" /></button>
        </div>, document.body)}
    </div>
  )
}
