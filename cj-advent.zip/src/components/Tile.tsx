import { useState } from 'react'
import { MOTIF } from '../utils/layout'

export type TileState = 'closed' | 'avail' | 'open'
type Props = {
  day: number; c: number; r: number; w: number; h: number; color: string
  state: TileState; today: boolean; special: boolean
  onActivate: (day: number) => void; onLocked: (day: number) => void
}

export default function Tile({ day, c, r, w, h, color, state, today, special, onActivate, onLocked }: Props) {
  const [shake, setShake] = useState(false)
  const size = w === 1 && h === 1 ? 'ts' : h === 1 ? 'tw-w' : 'tb' + (h >= 3 ? ' tall' : '')
  const label = `Día ${day}, ${state === 'closed' ? `se abre el ${day} de diciembre` : state === 'open' ? 'abierto' : 'disponible'}`
  const cls = ['tile', color, state, special && 'sp', state === 'avail' && today && 'today', shake && 'shake'].filter(Boolean).join(' ')
  return (
    <button type="button" className={cls} aria-label={label}
      style={{ gridColumn: `${c}/span ${w}`, gridRow: `${r}/span ${h}` }}
      onAnimationEnd={e => { if (e.animationName === 'shake') setShake(false) }}
      onClick={() => { if (state === 'closed') { setShake(true); onLocked(day) } else onActivate(day) }}>
      <span className="room">
        <svg viewBox="0 0 64 64"><use href="#i-heart" /></svg>
        <span>{day}</span>
      </span>
      <span className={`leaf ${size}`}>
        <b className="num">{day}</b>
        {size !== 'ts' && <svg className="m" viewBox="0 0 64 64"><use href={`#i-${MOTIF[day]}`} /></svg>}
        <svg className="lk" viewBox="0 0 64 64"><use href="#i-lock" /></svg>
      </span>
    </button>
  )
}
