export type ContentType = 'letter' | 'gallery' | 'video' | 'audio' | 'voucher' | 'quiz' | 'riddle' | 'experience'
export interface CalendarDay { day_number: number; unlock_at: string; available: boolean; opened: boolean }
export interface Surprise {
  day_number: number; title: string; subtitle: string | null
  content_type: ContentType; content: Record<string, any>; redeemed: boolean
  /** ruta "bucket/objeto" → URL firmada temporal */
  media?: Record<string, string>
}
