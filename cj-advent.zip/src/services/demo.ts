import type { ContentType, Surprise } from './types'

const TYPES: ContentType[] = ['letter','gallery','audio','letter','video','quiz','voucher','gallery','audio','gallery',
  'riddle','letter','audio','voucher','video','letter','quiz','riddle','letter','video',
  'gallery','letter','voucher','letter','experience']

const CONTENT: Partial<Record<ContentType, Record<string, any>>> = {
  letter: { body: 'Aquí irá tu sorpresa', signature: 'Joan' },
  voucher: { description: 'Aquí irá tu sorpresa', conditions: 'Condiciones de demostración' },
  quiz: { questions: [{ q: 'Pregunta de demostración', options: ['Respuesta A', 'Respuesta B'], correct: 0 }], final_message: 'Aquí irá tu mensaje final' },
  riddle: { text: 'Aquí irá tu acertijo', hint: 'Aquí irá la pista', answer: 'respuesta', success_message: '¡Resuelto!' }
}

export function demoSurprise(day: number): Surprise {
  const t = TYPES[day - 1]
  return {
    day_number: day, title: `Día ${day}`, subtitle: 'Contenido de demostración', content_type: t,
    content: CONTENT[t] ?? { description: 'Aquí irá tu sorpresa' },
    redeemed: localStorage.getItem(`cj-redeemed-${day}`) === '1'
  }
}
