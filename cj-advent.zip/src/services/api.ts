import { createClient } from '@supabase/supabase-js'
import type { CalendarDay, Surprise } from './types'
import { TOTAL, getNow, loadOpened, saveOpened, unlockAt } from '../utils/advent'
import { demoSurprise } from './demo'

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined
const key = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined
const sb = url && key ? createClient(url, key) : null

/** Sin variables de entorno la app funciona en modo demo (sin seguridad real). */
export const isDemo = !sb

const TK = 'cj-token'
export const getToken = (): string | null => { try { return localStorage.getItem(TK) } catch { return null } }
export const setToken = (t: string) => { try { localStorage.setItem(TK, t) } catch { /* ignorar */ } }
export const hasAccess = () => isDemo || !!getToken()

async function rpc<T>(fn: string, args: Record<string, unknown> = {}): Promise<T> {
  const { data, error } = await sb!.rpc(fn, { p_token: getToken(), ...args })
  if (error) throw new Error(error.message)
  return data as T
}

export async function getCalendar(): Promise<CalendarDay[]> {
  if (sb) return rpc<CalendarDay[]>('get_calendar')
  const now = getNow(), opened = loadOpened()
  return Array.from({ length: TOTAL }, (_, i) => i + 1).map(d => ({
    day_number: d, unlock_at: new Date(unlockAt(d)).toISOString(),
    available: now >= unlockAt(d), opened: opened.includes(d)
  }))
}

export async function openDay(day: number): Promise<Surprise> {
  if (sb) {
    const r = await rpc<Surprise[]>('open_day', { p_day: day })
    if (!r?.length) throw new Error('not_available')
    const s = r[0]
    if (['gallery', 'video', 'audio'].includes(s.content_type)) s.media = await signMedia(day)
    return s
  }
  if (getNow() < unlockAt(day)) throw new Error('not_available')
  const o = loadOpened()
  if (!o.includes(day)) saveOpened([...o, day])
  return demoSurprise(day)
}

export async function redeem(day: number): Promise<void> {
  if (sb) return rpc<void>('redeem_day', { p_day: day })
  localStorage.setItem(`cj-redeemed-${day}`, '1')
}

/** URLs firmadas (1 h). Si falla, la sorpresa se muestra sin archivos en vez de romperse. */
async function signMedia(day: number): Promise<Record<string, string>> {
  try {
    const { data, error } = await sb!.functions.invoke('sign-media', { body: { token: getToken(), day } })
    if (error) return {}
    return (data?.urls ?? {}) as Record<string, string>
  } catch { return {} }
}
